function setup() {
    let audio1 = new Audio('sound.mp3');
    audio1.play();
}